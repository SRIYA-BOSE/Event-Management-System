const express = require('express');
const { getEvents, createEvent, deleteEvent } = require('../controllers/eventController'); // Import all functions
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Protect all event routes
router.use(authMiddleware);

// Define routes
router.get('/', getEvents); // Use getEvents here
router.post('/', createEvent);
router.delete('/:id', deleteEvent);

module.exports = router;