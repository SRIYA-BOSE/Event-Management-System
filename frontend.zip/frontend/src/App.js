import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, Container, Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, Snackbar } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import AddIcon from '@mui/icons-material/Add';
import Login from './components/Login';
import Signup from './components/Signup';
import EventForm from './components/EventForm';
import EventList from './components/EventList';
import { getEvents, login, signup, setAuthToken, createEvent, deleteEvent } from './services/api';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [events, setEvents] = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  useEffect(() => {
    if (token) {
      setAuthToken(token);
      fetchEvents();
    }
  }, [token]);

  const fetchEvents = async () => {
    try {
      const response = await getEvents();
      setEvents(response.data);
    } catch (err) {
      console.error('Failed to fetch events', err);
    }
  };

  const handleLogin = async (credentials) => {
    try {
      const response = await login(credentials);
      setToken(response.data.token);
      localStorage.setItem('token', response.data.token);
      setAuthToken(response.data.token);
      setSnackbarMessage('Login successful');
      setSnackbarOpen(true);
    } catch (err) {
      setSnackbarMessage('Login failed');
      setSnackbarOpen(true);
    }
  };

  const handleSignup = async (credentials) => {
    try {
      await signup(credentials);
      setSnackbarMessage('Signup successful. Please login.');
      setSnackbarOpen(true);
    } catch (err) {
      setSnackbarMessage('Signup failed');
      setSnackbarOpen(true);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setAuthToken(null);
    setSnackbarMessage('Logged out successfully');
    setSnackbarOpen(true);
  };

  const handleAddEvent = async (event) => {
    try {
      await createEvent(event);
      fetchEvents();
      setSnackbarMessage('Event created successfully');
      setSnackbarOpen(true);
    } catch (err) {
      setSnackbarMessage('Failed to create event');
      setSnackbarOpen(true);
    }
  };

  const handleDeleteEvent = async (id) => {
    try {
      await deleteEvent(id);
      fetchEvents();
      setSnackbarMessage('Event deleted successfully');
      setSnackbarOpen(true);
    } catch (err) {
      setSnackbarMessage('Failed to delete event');
      setSnackbarOpen(true);
    }
  };

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setDrawerOpen(open);
  };

  return (
    <Router>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={toggleDrawer(true)} sx={{ mr: 2, display: { sm: 'none' } }}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Event Management System
          </Typography>
          {token ? (
            <Button color="inherit" onClick={handleLogout}>Logout</Button>
          ) : (
            <>
              <Button color="inherit" href="/login">Login</Button>
              <Button color="inherit" href="/signup">Signup</Button>
            </>
          )}
        </Toolbar>
      </AppBar>
      <Drawer anchor="left" open={drawerOpen} onClose={toggleDrawer(false)}>
        <List>
          <ListItem button onClick={toggleDrawer(false)}>
            <ListItemIcon>
              <AddIcon />
            </ListItemIcon>
            <ListItemText primary="Create Event" />
          </ListItem>
        </List>
      </Drawer>
      <Container sx={{ marginTop: 4 }}>
        <Routes>
          <Route path="/login" element={!token ? <Login onLogin={handleLogin} /> : <Navigate to="/" />} />
          <Route path="/signup" element={!token ? <Signup onSignup={handleSignup} /> : <Navigate to="/" />} />
          <Route
            path="/"
            element={
              token ? (
                <>
                  <EventForm onAddEvent={handleAddEvent} />
                  <EventList events={events} onDeleteEvent={handleDeleteEvent} />
                </>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </Container>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />
    </Router>
  );
}

export default App;