import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

// Set the authorization header with the token
export const setAuthToken = (token) => {
  if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete axios.defaults.headers.common['Authorization'];
  }
};

// Authentication
export const signup = (user) => axios.post(`${API_URL}/auth/signup`, user);
export const login = (user) => axios.post(`${API_URL}/auth/login`, user);

// Events
export const getEvents = () => axios.get(`${API_URL}/events`);
export const createEvent = (event) => axios.post(`${API_URL}/events`, event);
export const deleteEvent = (id) => axios.delete(`${API_URL}/events/${id}`); 