import React from 'react';
import { Card, CardContent, Typography, Button, Grid } from '@mui/material';
import { deleteEvent } from '../services/api';

const EventList = ({ events, onDeleteEvent }) => {
  const handleDelete = async (id) => {
    try {
      await deleteEvent(id); // Call the deleteEvent API
      onDeleteEvent(); // Refresh the event list
    } catch (err) {
      alert('Failed to delete event');
    }
  };

  return (
    <Grid container spacing={3}>
      {events.map((event) => (
        <Grid item key={event._id} xs={12} sm={6} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h5" component="div">
                {event.title}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {event.description}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {new Date(event.date).toLocaleDateString()}
              </Typography>
              <Button
                variant="contained"
                color="error"
                onClick={() => handleDelete(event._id)} // Pass the event ID
                sx={{ marginTop: 2 }}
              >
                Delete
              </Button>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default EventList;