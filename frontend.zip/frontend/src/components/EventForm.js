import React, { useState } from 'react';
import { TextField, Button, Box, Typography, useMediaQuery, Fab } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

const EventForm = ({ onAddEvent }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const isMobile = useMediaQuery('(max-width:600px)');

  const handleSubmit = async (e) => {
    e.preventDefault();
    onAddEvent({ title, description, date });
    setTitle('');
    setDescription('');
    setDate('');
  };

  return (
    <Box sx={{ maxWidth: isMobile ? '90%' : 400, margin: 'auto', marginTop: 4 }}>
      <Typography variant="h4" align="center" gutterBottom>
        Create Event
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          fullWidth
          label="Title"
          variant="outlined"
          margin="normal"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <TextField
          fullWidth
          label="Description"
          variant="outlined"
          margin="normal"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <TextField
          fullWidth
          type="date"
          variant="outlined"
          margin="normal"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
        <Button type="submit" fullWidth variant="contained" sx={{ marginTop: 2 }}>
          Create Event
        </Button>
      </form>
      <Fab
        color="primary"
        aria-label="add"
        sx={{ position: 'fixed', bottom: 16, right: 16 }}
        onClick={handleSubmit}
      >
        <AddIcon />
      </Fab>
    </Box>
  );
};

export default EventForm;